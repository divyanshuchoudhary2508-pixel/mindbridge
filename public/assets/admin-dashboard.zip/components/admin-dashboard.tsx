"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  BarChart3,
  Users,
  FileText,
  Settings,
  Search,
  Bell,
  Menu,
  TrendingUp,
  Eye,
  MessageSquare,
  DollarSign,
  Plus,
  MoreHorizontal,
  Edit,
  Trash2,
} from "lucide-react"
import { cn } from "@/lib/utils"

const sidebarItems = [
  { icon: BarChart3, label: "Analytics", active: true },
  { icon: Users, label: "Users", active: false },
  { icon: FileText, label: "Content", active: false },
  { icon: Settings, label: "Settings", active: false },
]

const analyticsData = [
  { title: "Total Users", value: "12,543", change: "+12%", icon: Users },
  { title: "Page Views", value: "45,231", change: "+8%", icon: Eye },
  { title: "Revenue", value: "$23,456", change: "+15%", icon: DollarSign },
  { title: "Comments", value: "1,234", change: "+5%", icon: MessageSquare },
]

const recentUsers = [
  { name: "Alice Johnson", email: "alice@example.com", status: "Active", avatar: "/diverse-woman-portrait.png" },
  { name: "Bob Smith", email: "bob@example.com", status: "Inactive", avatar: "/thoughtful-man.png" },
  { name: "Carol Davis", email: "carol@example.com", status: "Active", avatar: "/diverse-woman-portrait.png" },
  { name: "David Wilson", email: "david@example.com", status: "Pending", avatar: "/thoughtful-man.png" },
]

const recentContent = [
  { title: "Getting Started Guide", type: "Article", status: "Published", date: "2 hours ago" },
  { title: "Product Update v2.1", type: "Blog Post", status: "Draft", date: "1 day ago" },
  { title: "FAQ Section", type: "Page", status: "Published", date: "3 days ago" },
  { title: "Terms of Service", type: "Legal", status: "Review", date: "1 week ago" },
]

export function AdminDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center px-4">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setSidebarOpen(!sidebarOpen)}>
            <Menu className="h-5 w-5" />
          </Button>

          <div className="flex items-center space-x-4 ml-4 md:ml-0">
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <BarChart3 className="h-5 w-5 text-primary-foreground" />
              </div>
              <h1 className="text-xl font-semibold">Admin Dashboard</h1>
            </div>
          </div>

          <div className="flex-1 flex items-center justify-center px-6">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search..." className="pl-10 bg-muted/50" />
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <Avatar>
              <AvatarImage src="/admin-interface.png" />
              <AvatarFallback>AD</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={cn(
            "fixed inset-y-0 left-0 z-40 w-64 bg-sidebar border-r border-sidebar-border transition-transform duration-300 ease-in-out md:relative md:translate-x-0",
            sidebarOpen ? "translate-x-0" : "-translate-x-full",
          )}
        >
          <div className="flex flex-col h-full pt-16 md:pt-0">
            <nav className="flex-1 px-4 py-6 space-y-2">
              {sidebarItems.map((item) => (
                <Button
                  key={item.label}
                  variant={item.active ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start",
                    item.active && "bg-sidebar-accent text-sidebar-accent-foreground",
                  )}
                >
                  <item.icon className="mr-3 h-5 w-5" />
                  {item.label}
                </Button>
              ))}
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 space-y-6">
          {/* Analytics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {analyticsData.map((item) => (
              <Card key={item.title}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">{item.title}</CardTitle>
                  <item.icon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{item.value}</div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <TrendingUp className="mr-1 h-3 w-3 text-primary" />
                    {item.change} from last month
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Users */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Recent Users</CardTitle>
                    <CardDescription>Latest user registrations</CardDescription>
                  </div>
                  <Button size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    Add User
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentUsers.map((user) => (
                    <div key={user.email} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={user.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {user.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium">{user.name}</p>
                          <p className="text-xs text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge
                          variant={
                            user.status === "Active" ? "default" : user.status === "Inactive" ? "secondary" : "outline"
                          }
                        >
                          {user.status}
                        </Badge>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Content */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Recent Content</CardTitle>
                    <CardDescription>Latest content updates</CardDescription>
                  </div>
                  <Button size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    New Content
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentContent.map((content) => (
                    <div key={content.title} className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="text-sm font-medium">{content.title}</p>
                        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                          <span>{content.type}</span>
                          <span>•</span>
                          <span>{content.date}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge
                          variant={
                            content.status === "Published"
                              ? "default"
                              : content.status === "Draft"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {content.status}
                        </Badge>
                        <div className="flex space-x-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
